import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, send_file
from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField, DecimalField
from wtforms.validators import DataRequired, NumberRange
from werkzeug.utils import secure_filename
from mlxtend.frequent_patterns import apriori, association_rules
import plotly.express as px
import os
from io import BytesIO
from mlxtend.preprocessing import TransactionEncoder


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = './uploads'

class UploadForm(FlaskForm):
    file = FileField('CSV File', validators=[DataRequired()])
    min_support = DecimalField('Minimum Support (%)', default=10.0, validators=[DataRequired(), NumberRange(min=0.0, max=100.0)])
    min_confidence = DecimalField('Minimum Confidence (%)', default=70.0, validators=[DataRequired(), NumberRange(min=0.0, max=100.0)])
    submit = SubmitField('Analyze')

def read_and_analyze(file_path, min_support, min_confidence):
    df = pd.read_csv(file_path, header=None)
    
    # Replace NaN values with an empty string, and ensure all items are strings
    transactions = df.fillna('').astype(str).values.tolist()
    
    # Initialize TransactionEncoder
    te = TransactionEncoder()
    te_ary = te.fit(transactions).transform(transactions)
    df_encoded = pd.DataFrame(te_ary, columns=te.columns_).astype(bool)
    
    # Perform Apriori algorithm
    frequent_itemsets = apriori(df_encoded, min_support=min_support / 100, use_colnames=True)
    rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=min_confidence / 100)

    # Compute additional metrics if needed
    # If not, simply comment out or remove the lines below
    rules['leverage'] = rules['leverage']
    rules['conviction'] = rules['conviction']
    rules['zhangs_metric'] = rules['lift'] / (1 - rules['consequent support']) - 1

    # Convert frozensets to strings
    rules['antecedents'] = rules['antecedents'].apply(lambda x: ', '.join(list(x)))
    rules['consequents'] = rules['consequents'].apply(lambda x: ', '.join(list(x)))

    # The support, confidence, and lift are already in the correct numeric format
    # They can be rounded here if needed for display purposes
    rules['support'] = rules['support']
    rules['confidence'] = rules['confidence']
    rules['lift'] = rules['lift']
    
    return rules

def create_charts(rules):
    fig = px.bar(rules, x='antecedents', y='support', title='Support of Antecedents')
    return fig.to_html(full_html=False)

@app.route('/', methods=['GET', 'POST'])
def index():
    form = UploadForm()
    if form.validate_on_submit():
        file = form.file.data
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        min_support = form.min_support.data
        min_confidence = form.min_confidence.data
        rules = read_and_analyze(file_path, min_support, min_confidence)
        rules.to_csv('static/results.csv', index=False)
        return redirect(url_for('results'))
    return render_template('index.html', form=form)

@app.route('/results')
def results():
    try:
        df = pd.read_csv('static/results.csv')
        df['support'] = df['support'].round(2)
        df['confidence'] = df['confidence'].round(2)
        df['lift'] = df['lift'].round(2)

        query = request.args.get('search', '')
        if query:
            df = df[df.apply(lambda row: row.astype(str).str.contains(query, case=False, na=False).any(), axis=1)]
        df = df.head(50)

        chart = create_charts(df) if not df.empty else ''
        return render_template('results.html', records=df.to_dict('records'), chart=chart)
    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/download')
def download():
    df = pd.read_csv('static/results.csv')  # Load your results CSV
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Results')
    output.seek(0)  # Rewind the buffer
    return send_file(output, 
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, 
                     download_name="AprioriResults.xlsx") 
    
    
if __name__ == '__main__':
    app.run(debug=True)
